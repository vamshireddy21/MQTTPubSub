package com.kroger.sps.mqtt.poc.pubsub;

import java.util.UUID;

import org.eclipse.paho.client.mqttv3.MqttException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.support.ExecutorSubscribableChannel;
import org.springframework.messaging.support.MessageBuilder;

import com.github.christophersmith.summer.mqtt.core.MqttClientConnectionType;
import com.github.christophersmith.summer.mqtt.core.service.MqttClientService;
import com.github.christophersmith.summer.mqtt.paho.service.PahoAsyncMqttClientService;
import com.kroger.sps.mqtt.poc.pubsub.consumer.MQTTConsumerHandler;

@Configuration
public class MQTTPubSub {

	@Autowired
	private MQTTConsumerHandler mqttConsumerHandler;

	@Autowired
	private MessageChannel mqttProducerHandler;

	private static final String mqtt_topic = "publishedMessages";

	@Bean
	public MqttClientService mqttPubSubMessages() throws MqttException {

		String connected = "CONNECTED";

		PahoAsyncMqttClientService service = new PahoAsyncMqttClientService("tcp://localhost:1883", "DemoPubSub",
				MqttClientConnectionType.PUBSUB, null);

		service.getMqttConnectOptions().setCleanSession(true);
		service.getMqttConnectOptions().setWill("status", connected.getBytes(), 1, false);

		service.subscribe(mqtt_topic);

		service.setInboundMessageChannel(mqttInboundMessageChannel());

		for (int i = 0; i <= 10; i++) {
			String publishMessage = "Message " + i + " = " + UUID.randomUUID().toString();
			System.out.println("MQTT Message Sent to topic: " + mqtt_topic + " with value: " + publishMessage);
			mqttProducerHandler
					.send(MessageBuilder.withPayload(publishMessage).setHeader("mqtt_topic", mqtt_topic).build());
		}

		service.start();
		return service;
	}

	@Bean
	public MessageChannel mqttInboundMessageChannel() {
		ExecutorSubscribableChannel messageChannel = new ExecutorSubscribableChannel();
		messageChannel.subscribe(mqttConsumerHandler);
		return messageChannel;
	}
}
