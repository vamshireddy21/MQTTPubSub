package com.kroger.sps.mqtt.poc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MqttDemoPocApplication {

	public static void main(String[] args) {
		SpringApplication.run(MqttDemoPocApplication.class, args);
	}

}
