package com.kroger.sps.mqtt.poc.pubsub.consumer;

import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHandler;
import org.springframework.stereotype.Component;

import com.github.christophersmith.summer.mqtt.core.util.MqttHeaderHelper;

@Component
public class MQTTConsumerHandler implements MessageHandler {

	@Override
	public void handleMessage(Message<?> message) {
		String consumerTopic = MqttHeaderHelper.getTopicHeaderValue(message);
		String consumedMessage = (String) message.getPayload();
		System.out.println("MQTT Message Received from topic: " + consumerTopic + " with value: " + consumedMessage);
	}
}
